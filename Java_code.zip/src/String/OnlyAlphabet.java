package String;

public class OnlyAlphabet {
    /**
     * 3. Removing Characters Except Alphabets
     * - Input Test Case: "Hello123"
     * - Expected Output: "Hello"
     *
     * @param args
     */
    static String onlyAlpha(String str) {
        String s1 = "";
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (Character.isAlphabetic(ch)) {
                s1 = s1 + ch;
            }
        }
        return s1;
    }
    public static void main(String[] args) {
        String str = "Hello123";
        System.out.println(onlyAlpha(str));
    }
}
