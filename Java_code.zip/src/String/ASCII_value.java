package String;

public class ASCII_value {

    public static void main(String[] args) {
        String str = "ABCD abcd  1234";

        for (int i = 0; i < str.length() ; i++) {
            char ch = str.charAt(i);
            int s = ch;
            System.out.println(s+ " ");}}}
