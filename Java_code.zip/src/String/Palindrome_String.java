package String;

public class Palindrome_String {


    public static void main(String[] args) {
        int a = 20;
        System.out.println("I AM MAIN");
        main(a);
    }
    public static void main(int a) {
        System.out.println(a);
    }
}

