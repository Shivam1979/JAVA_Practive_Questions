package String;

public class sample {

    int x = 5, y = 5, z = 0;

    public void method() {

        try {
            z = x + y;
            System.out.println(+z);
        } catch (Exception e) {
            System.out.println("17 ");
        }
    }

    public void method(int a, int b) {
        x = a;
        y = b;
        z = x + y;
        System.out.println(" " + z);
    }

    public int method(int a) {
        x = a;
        z = x + y;
        return z;
    }


}
