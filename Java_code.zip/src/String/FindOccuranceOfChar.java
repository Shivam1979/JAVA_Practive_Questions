package String;
public class FindOccuranceOfChar{
    public static void main(String[] args) {
        sample obj = new sample();
        obj.method();
        obj.method('a','b');
        System.out.println(" "+obj.method('a'));

    }
}
