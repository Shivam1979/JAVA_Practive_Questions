package A_DateWise;

public class DeleteMid {

//8. Remove Middle Element of the LinkedList

    public static void main(String[] args) {
        LinkedList l = new LinkedList();
        Node head = null;
        head = l.addLast(head, 1);
        head = l.addLast(head, 2);
        head = l.addLast(head, 3);
        head = l.addLast(head, 4);
        head = l.addLast(head, 5);
        l.printList(head);

        System.out.println(middleElement(head));
        l.printList(head);

    }

    static int middleElement(Node head){
        Node temp = head;
        Node slow = temp;
        Node fast = temp;
        while ( fast.next != null){
          slow = slow.next;
          fast = fast.next.next;
          if (fast == null){
              slow = slow.next.next;
            break;
          }
        }
      //  slow = slow.next;
        return slow.data;
    }

    static int mid(Node head){
        Node pont1 = head;
        Node pont2 = head;
        while (pont2 != null && pont2.next!=null  ){
            pont2 = pont2.next.next;
            pont1 = pont1.next;
        }
        return pont1.data;
    }

}
