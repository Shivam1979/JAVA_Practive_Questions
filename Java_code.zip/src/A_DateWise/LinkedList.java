package A_DateWise;

public class LinkedList {

     void printList(Node head) {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + "-->");
            temp = temp.next;
        }
        System.out.println("null");
    }
    //Add First
     Node addFirst(Node head, int data) {
        Node new_node = new Node(data);
        if (head == null) {
            return new_node;
        }
        new_node.next = head;
        head = new_node;
        return head;
    }
     Node addLast(Node head, int data) {
        Node new_node = new Node(data);
        if (head == null) {
            return new_node;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = new_node;
        return head;
    }
    public static void main(String[] args) {
         LinkedList l = new LinkedList();
        Node head = null;
        head = l.addFirst(head, 12);
        head = l.addFirst(head, 13);
        l.printList(head);
        head = l.addLast(head, 1);
        head = l.addLast(head, 3);
        l.printList(head);
    }

}
