package Collection.Arraylist.Map;

import Hashset.LinkedHashSet.Hashset;

import java.util.HashMap;

public class Implementation {
    public static void main(String[] args) {
        HashMap <String ,Integer> courses = new HashMap<>();
        courses.put("Core Java" , 4000);
        courses.put("Basic Python" , 3500);
        courses.put("Sql" , 3000);
        courses.put("Sql" , 2000);// duplicate key is not allowed

//courses.
//        System.out.println(courses);

    }
}
