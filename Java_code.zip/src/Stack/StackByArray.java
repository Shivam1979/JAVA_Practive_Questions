package Stack;

/**
 * 6.  Implement  the Stack  using Array and perform the below operations
 * - Input Test Case: push(5), push(8), pop, push(2), push(5), pop, pop, pop, push(1),   pop
 */
public class StackByArray {
    static int arr[] = new int[10];
    static int top = -1;
    static void push(int data) {
        top = top + 1;
        arr[top] = data;
    }
    static int pop() {
        arr[top] = 0;
        return arr[top--];
        //top = top -1;
    }
    static boolean isEmpty() {
        if (top == -1) {
            return true;
        }
        return false;
    }
    static void size() {
        System.out.println(top + 1);
    }
    static void printStack() {
        for (int i = arr.length - 1; i >= 0; i--) {
            if (arr[i] != 0) {
                System.out.println("| " + arr[i] + " |");
            }
        }
        System.out.println(" ---");
        System.out.println("    ");
    }
    public static void main(String[] args) {
        push(5);
        push(8);
        pop();
        push(2);
        push(5);
        printStack();
        pop();
        pop();
        pop();
        push(1);
        pop();
        printStack();
        System.out.println(isEmpty());
    }

}
