package Stack;

/**
 * 2. *Implement a stack using arrays* 📚
 *    - Test Case:
 *      - Input: Push 5, Push 3, Pop, Push 2
 *      - Expected Output: Stack: [5, 2]
 */
public class StackUsingArray {
    static int arr[] = new int[5];
    static int top = -1;

    static void push(int x) {
        top = top + 1;
        arr[top] = x;
    }

    static void pop() {
        top = top - 1;
    }
    static void top() {
        System.out.println(arr[top]);
    }
    static void size() {
        System.out.println(top + 1);
    }
    static void isEmpty() {
        if (top == -1) System.out.println("true");
        else System.out.println("false");
    }
    static void printStack(){
        for (int i = 0; i < arr.length; i++) {
            if (arr[i]!=0){
                System.out.print(arr[i]+" ");
            }
        }
    }
    public static void main(String[] args) {
        size();
        push(5);
        push(3);
        pop();
        push(2);
        printStack();
    }

}
