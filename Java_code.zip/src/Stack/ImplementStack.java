package Stack;

import LinkedList.Node;


class MyStack{
    Node head;
   public int size;

    public MyStack(){
        head = null;
        size = 0;
    }

}
public class ImplementStack extends MyStack {
    static void  push(int data,Node head){
        Node new_node = new Node(data);
        new_node.next= head;
        head = new_node;

    }

    public static void main(String[] args) {
        Node head = null;


    }
}
