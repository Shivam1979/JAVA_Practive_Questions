package Arrays;

public class DEmo1 {
    public static void main(String[] args) {
        Demo ob = new Demo();
        ob.run();
    }
}
