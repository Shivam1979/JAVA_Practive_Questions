package Arrays;

import java.util.Scanner;

public class Demo {


      protected void run() {
        System.out.println(" i am running");
      }
}
