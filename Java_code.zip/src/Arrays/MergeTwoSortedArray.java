package Arrays;

/**
 * 335. Merge Two Sorted Arrays:
 *    - Input:
 *      Array 1: [1, 3, 5, 7]
 *      Array 2: [2, 4, 6, 8]
 *    - Output:
 *      Merged Array: [1, 2, 3, 4, 5, 6, 7, 8]
 */
public class MergeTwoSortedArray {


    public static void main(String[] args) {
        int arr1 [] = {1, 3, 5, 7};
        int arr2 [] = {2, 4, 6, 8};

        int mer [] = new int[(arr1.length+arr2.length)];
        for (int i = 0; i < mer.length; i++) {

        }
    }
}
