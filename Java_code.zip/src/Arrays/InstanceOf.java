package Arrays;

public class InstanceOf {
}
