package Arrays;

import java.util.Arrays;

/**
 * 1. *Create a function to remove duplicates from a sorted array* 🔄
 * - Test Case:
 * - Input: [2, 3, 3, 3, 4, 5, 5]
 * - Expected Output: [2, 3, 4, 5]
 */
public class RemoveDuplicateinSorted {
    public static void main(String[] args) {
        int arr[] = {2, 3, 3, 3, 4, 5, 5};
        for (int i = 0; i <arr.length ; i++) {
            System.out.print(" "+arr[i]);
        }
        int j = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[j] != arr[i]){
             arr[j+1] = arr[i];
             j++;
            }
        }
        System.out.println();
        for (int i = 0; i <=j ; i++) {
            System.out.print(" "+arr[i]);
        }
    }
}
