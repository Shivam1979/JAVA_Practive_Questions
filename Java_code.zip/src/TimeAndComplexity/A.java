package TimeAndComplexity;

public class A {

    public static void main(String[] args) {

    }

}
