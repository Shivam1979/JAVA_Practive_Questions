package OOPs.Encapsulation;

public class UBI {


}
