package OOPs.Encapsulation;

public class SBI {

    public static void main(String[] args) {

    }

}
