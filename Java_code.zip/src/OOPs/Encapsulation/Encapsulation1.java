package OOPs.Encapsulation;


public class Encapsulation1 {


}
