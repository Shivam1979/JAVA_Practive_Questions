package OOPs;

public class OOPsExplain {
     /*OOPS stand for the OBJECT ORIENTED PROGRAMMING it means those launguage that are using object in the programming
                                        *//*  4 Pillar  of OOPS*//*

    Encapsulation : - In incapsulation we bind the data member and member funstion in same unit that is class ,
     Java by default provide the encapsulation because we write code inside the class  but if we want to achieve the
    100% the we declare the global variable as private and we acses then by using get and set method , for method and class we have acsess modifier
    Public , private , default and protected


    Polymorphism : - Polymorphism  , poly means many morf means form so ability to achieve the various form is calles the polymorphism
     we can achieve by two way
                                 1.--------Overloading(Compile Time ) early binding ..> static binding
                                  2------------ Overriding (Run time )Late binding.... > Dyanmic binding
    Abstraction :- Abstraction means , to show only esential detail or usefull detail and hide the implementaion
    there are two way to achive data abstraction 1 . Abstract Class (0%------------100%)
    2. Interface 100%
   Inheritance  : - to inherit the property of parent class to child class is called a inheritance
     * we use extend keyword
    1. single level inheritance
    2. Multilevel level inheritance
    3. hybrid level inheritance
    4. multiple level inheritance
*/


}
