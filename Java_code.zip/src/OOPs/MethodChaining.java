package OOPs;

public class MethodChaining {


}
