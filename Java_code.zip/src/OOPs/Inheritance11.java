package OOPs;

public class Inheritance11 {

}
