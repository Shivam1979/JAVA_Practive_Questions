package OOPs;






public class ConstructorChainnig {

    public static void main(String[] args) {






    }
}
