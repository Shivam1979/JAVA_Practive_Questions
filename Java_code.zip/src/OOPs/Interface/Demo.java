package OOPs.Interface;

interface Animal{
    int eat(int a);
}
public class Demo {

    int a ;
    String name;


    public static void main(String[] args) {

    }
}
