package Queue.Prority;

public class Priority1 {

}
