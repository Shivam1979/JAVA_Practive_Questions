package Optional;

public class Demo1 {

    public static void main(String[] args) {
        int a = 5;
        int b = 3;
        System.out.println(a & b); // 0101 , 0011   0001-->1
        System.out.println(a|b);    // 0101 , 0011   0111-->7
        System.out.println(~a); //0101 -->1010-->10
        System.out.println(~b);// 0011-->1100-->12
        System.out.println(a^b); // X-OR  -->6
        System.out.println(a<<2);//0101-->0010
        System.out.println(b>>1);//0101-->0001


    }
}
