package LinkedList;

import Stack.Implement_stack;

public class Node {
    public Node next;
    public int data;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}
