package LinkedList;

public class FindMiddle {
    static Node addLast(int data, Node head) {
        Node new_node = new Node(data);
        if (head == null) {
            return new_node;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = new_node;
        return head;
    }

    static void printList(Node head) {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " --> ");
            temp = temp.next;
        }
        System.out.print("null");
        System.out.println();
    }

    static int findMid(Node head) {
        Node pont1 = head;
        Node pont2 = head;
        while (pont2 != null && pont2.next!=null  ){
               pont2 = pont2.next.next;
               pont1 = pont1.next;
        }
        return pont1.data;
    }

    public static void main(String[] args) {
        Node head = null;
        head = addLast(1, head);
        head = addLast(2, head);
        head = addLast(3, head);
        head = addLast(4, head);
        head = addLast(5, head);
        head = addLast(6, head);
//        head = addLast(7, head);
        printList(head);
        System.out.println(findMid(head));

    }
}
