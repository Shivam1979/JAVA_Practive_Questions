package LinkedList;

public class DetectLoop {
}
