package LinkedList;

public class FindMiddlel {
    static void printList(Node head) {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ---> ");
            temp = temp.next;
        }
        System.out.print("null");
        System.out.println();
    }

    static public Node addLast(int data, Node head) {
        Node new_node = new Node(data);
        if (head == null) {
            return new_node;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = new_node;
        return head;
    }

    static int findMiddle(Node head) {
        Node slow = head;
        Node fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow.data;
    }


    static Node detectloop(Node head) {
        Node slow = head;
        Node fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                return slow;
            }
        }
        return slow;
    }

    static int detectelemet(Node head) {
        Node pointer1 = detectloop(head);
        Node copy = pointer1;

        Node pointer2 = head;
        while (pointer2 != pointer1) {
            pointer2 = pointer2.next;
            pointer1 = pointer1.next;
        }
        Node copy1 = pointer2;
        while (copy1.next == copy) {
            copy1 = copy1.next;
        }
        copy1.next = null;
        return 1;
    }


    public static void main(String[] args) {
        Node head = null;
        head = addLast(1, head);
        head = addLast(2, head);
        head = addLast(3, head);
        head = addLast(4, head);
        head = addLast(5, head);
        head = addLast(6, head);
        printList(head);
        System.out.println(findMiddle(head));

    }
}
