// package TCS_CodeVita;

import java.util.*;
import java.lang.*;
//Shivam Singh
public class BestBubble{

    static int countSwapsasc(int[] arr) {
        int swaps = 0;
        int n = arr.length;

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swaps++;
                }
            }
        }

        return swaps;
    }


    static int countSwapsdesc(int[] arr) {
        int swaps = 0;
        int n = arr.length;

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] < arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swaps++;
                }
            }
        }

        return swaps;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int N = scanner.nextInt();

        int[] arr = new int[N];
        for (int i = 0; i < N; i++) {
            arr[i] = scanner.nextInt();
        }

        int[] ascendingArr = arr.clone();
        int[] descendingArr = arr.clone();

        int ascendingSwaps = countSwapsasc(ascendingArr);
        int descendingSwaps = countSwapsdesc(descendingArr);

        if (ascendingSwaps < descendingSwaps) {
            System.out.print(ascendingSwaps);
        } else
            System.out.print(descendingSwaps);

}
}