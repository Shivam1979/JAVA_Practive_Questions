
import java.util.Scanner;
import java.util.ArrayList;
// shivamSingh
public class UniqueCode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String inputString = scanner.nextLine();

        long boxesCount, consecutiveCount;
        boxesCount = scanner.nextLong();
        consecutiveCount = scanner.nextLong();

        ArrayList<Long> boxes = new ArrayList<>();


        Scanner inputStream = new Scanner(inputString);
        while (inputStream.hasNext()) {
            boxes.add(Long.parseLong(inputStream.next()));
        }


        ArrayList<Long> consecutiveCheck = new ArrayList<>();
        long totalAmount = 0;

        while (consecutiveCheck.size() < consecutiveCount) {
            for (int i = 0; i < boxesCount - 1; i++) {
                long first = boxes.get(0);
                long second = boxes.get(1);
                long minVal = Math.min(first, second);

                if (minVal == first) {
                    boxes.add(first);
                    if (!isTriangular(first)) {
                        totalAmount += first;
                    }
                    boxes.remove(0);
                } else if (minVal == second) {
                    boxes.add(second);
                    if (!isTriangular(second)) {
                        totalAmount += second;
                    }
                    boxes.remove(1);
                }
            }

            long maxVal = boxes.get(0);
            int l = consecutiveCheck.size();
            if (l != 0 && !consecutiveCheck.get(l - 1).equals(maxVal)) {
                consecutiveCheck.clear();
            }
            consecutiveCheck.add(maxVal);
        }

        System.out.println(totalAmount);
        scanner.close();
    }

    private static boolean isTriangular(long sum) {
        long n = 0;
        while ((n * (n + 1)) / 2 < sum) {
            n++;
        }
        return (n * (n + 1)) / 2 == sum;
    }
}