package TCS_CodeVita;

public @interface Bouncing {

}
