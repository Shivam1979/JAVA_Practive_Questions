

import java.util.Scanner;

public class UniqueBallMovement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows, cols, ball1_X, ball1_Y, ball2_X, ball2_Y, move1_X, move1_Y, move2_X, move2_Y;
        rows = scanner.nextInt();
        cols = scanner.nextInt();
        ball1_X = scanner.nextInt();
        ball1_Y = scanner.nextInt();
        move1_X = scanner.nextInt();
        move1_Y = scanner.nextInt();
        ball2_X = scanner.nextInt();
        ball2_Y = scanner.nextInt();
        move2_X = scanner.nextInt();
        move2_Y = scanner.nextInt();

        int time = 0;
        int initialBall1_X = ball1_X, initialBall1_Y = ball1_Y, initialBall2_X = ball2_X, initialBall2_Y = ball2_Y;
        int test = rows + cols - 1;
        boolean flag = false;

        while (true) {
            if (ball1_X == ball2_X && ball1_Y == ball2_Y) break;
            if (((initialBall1_X == ball1_X && initialBall1_Y == ball1_Y) || (initialBall2_X == ball2_X && initialBall2_Y == ball2_Y)) && time != 0 && test <= 0) {
                flag = true;
                break;
            }
            if (ball1_X == rows || ball1_X == 1)
                move1_X = -move1_X;
            if (ball1_Y == cols || ball1_Y == 1)
                move1_Y = -move1_Y;
            if (ball2_X == rows || ball2_X == 1)
                move2_X = -move2_X;
            if (ball2_Y == cols || ball2_Y == 1)
                move2_Y = -move2_Y;

            time++;
            ball1_X += move1_X;
            ball1_Y += move1_Y;
            ball2_X += move2_X;
            ball2_Y += move2_Y;

            test--;
        }

        if (flag)
            System.out.println("Never");
        else
            System.out.println(time);
    }
}