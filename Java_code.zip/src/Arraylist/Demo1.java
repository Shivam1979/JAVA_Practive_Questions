package Arraylist;

public class Demo1 {
     void display(int a ) {
        System.out.println("ghj");
    }

     void display(int a , int b) {
        System.out.println("ghj");
    }
}
