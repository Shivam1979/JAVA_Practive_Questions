package Arraylist;

public class WithoutSemi {

}
