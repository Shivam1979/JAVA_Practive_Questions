package Arraylist;

public class Demo2 extends Demo1{


    @Override
    void display(int a) {
        super.display(a);
    }

    public static void main(String[] args) {


    }
}
