package Arraylist;

public class SumOfMultiples {
    public static void main(String[] args) {
        boolean x = true; // 1
        boolean y = false; // 0
        boolean z = true; // 1
        boolean a = false; // 0
//      AND  * ----------------------OR+
        System.out.println("samsher");
        boolean s1 = z||x;// true
        boolean s2 = z||y;// false
        boolean s3 = z||z;//true
        boolean s4 = z||a;// false
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
        System.out.println("--------------------");

        // shivani
        System.out.println("shivani");
        boolean c1 = y||x;// false
        boolean c2 = y||y;// false
        boolean c3 = y||z; //  false
        boolean c4 = y||a;//  false
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);
        System.out.println("--------------------");
        // buta
        System.out.println("buta");
        boolean b1 = x||x;// true
        boolean b2 = x||y;// false
        boolean b3 = x||z;// true
        boolean b4 = x||a;// false
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        System.out.println(b4);



















    }
}
