package Numbers;

import com.sun.tools.javac.Main;

public class Pri {

    public static void main(String[] args) {

        for(; ;)
        for(; ;)
        System.out.println("Hello");

    }
}
