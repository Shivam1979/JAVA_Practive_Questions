package Numbers;

import java.util.Random;

public class Random_number {


    public static void main(String[] args) {
        Random r = new Random();
        System.out.println(r.nextInt(500));
    }
}
