package Numbers;

public class FindPrimenumberinRange {

    public static void main(String[] args) {
        
    }
}
