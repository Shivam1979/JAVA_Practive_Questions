package Numbers;

public class SecondLargestAndSecondSmallest {


    public static void main(String[] args) {
        int arr[] = {5, 2, 9, 1, 7, 3};
        // for smallest
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        System.out.println("max :" + max);
        System.out.println("min :" + min);
        int secMin = Integer.MAX_VALUE;
        int secMax = Integer.MIN_VALUE;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < secMin && arr[i] != min) {
                secMin = arr[i];
            }
            if (arr[i] > secMax && arr[i] != max) {
                secMax = arr[i];
            }
        }
        System.out.println("Second Max : "+secMax);
        System.out.println("Second Min : "+secMin);


    }

}
