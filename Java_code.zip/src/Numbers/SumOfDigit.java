package Numbers;

/**
 * 2. Sum of Digits
 * - Input Test Case: 12345
 * - Expected Output: 15
 */
public class SumOfDigit {

    public static void main(String[] args) {
        int n = 12345;
        System.out.println(sumOfDigit(n));
    }
    static  int sumOfDigit(int n ) {
        int num = n;
        int sum = 0;
        while (num > 0) {
            int b = num % 10;
            sum = sum + b;
            num =num/ 10;
        }
        return sum;
    }
}
