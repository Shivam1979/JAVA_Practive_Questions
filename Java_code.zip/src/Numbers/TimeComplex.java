package Numbers;

public class TimeComplex {
    public static void main(String[] args) {

        int n = 3;

        for (int i = 0; i < n; i++) {
            System.out.println("d");
        }

        for (int i = 0; i < n; i++) {
            System.out.println("hello");

            for (int j = 0; j < n; j++) {
                System.out.println("d");
            }


        }

    }
}
