package Numbers;
public class tcs1 {
    /**
     * Input
     * 3 4 5 1
     * Output
     * 61
     * @param args
     */
    public static void main(String[] args) {
        int smallest = 1;
        int n1 = 3;
        int n2 = 4;
        int n3 = 5;
        int num = 2;
        while (true) {
            if (num % n1 == smallest && num % n2 == smallest && num % n3 == smallest && num != smallest) {
                chekprime(num);
                break;
            }
            num++;
        }
    }
    static void chekprime(int n) {
        for (int i = 2; i <=n/2 ; i++) {
            if (n%i==0){
                System.out.println("none");
                break;
            }else{
                System.out.println(" " + n);
                break;
            }

        }
    }

}
