package Numbers;

public class BinToDecimal {
    /**
     * 1. Binary-to-Decimal Conversion
     * - Input Test Case: "101010"
     * - Expected Output: 42
     * @param
     *
     */
    static int binaryToDecimal(int n) {
        int sum = 0;
        int i = 0;
        while (n > 0) {
            int b = n % 10;
            sum = (int) (sum + b * Math.pow(2, i));
            i++;
            n = n / 10;
        }
        return sum;
    }
    public static void main(String[] args) {
        int n = 101010;
        System.out.println(binaryToDecimal(n));
    }
}
