package Numbers;

/**
 * 3. Replace all 0s with 5s in a given integer.
 * - Test Case:
 * - Input Integer: 1020450
 * - Expected Output: 1521455
 */
public class ReplaceOsby5s {


    public static void main(String[] args) {
        int n = 1020450;
        int num = n;  int temp = 1;
        int sum  = 0;
        while (num > 0) {
            int b = num % 10;
            if (b==0){
                b = 5;
            }
            sum = b*temp + sum;
            temp = temp * 10;
            num = num/10;
        }
        System.out.println(sum);
    }
}
