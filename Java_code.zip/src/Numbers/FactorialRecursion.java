package Numbers;

/**
 * 3. *Create a function to find the factorial of a number using recursion* 🔄
 * - Test Case:
 * - Input: 5
 * - Expected Output: 120
 */
public class FactorialRecursion {
    static int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else return n * factorial(n - 1);
    }
    public static void main(String[] args) {
        System.out.println(factorial(5));
    }
}
