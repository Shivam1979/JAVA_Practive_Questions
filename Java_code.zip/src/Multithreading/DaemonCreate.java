package Multithreading;

public class DaemonCreate {
    public static void main(String[] args) {

    }
}
