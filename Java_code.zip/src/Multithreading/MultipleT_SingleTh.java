package Multithreading;

public class MultipleT_SingleTh { // not possible , if we acheive 1 t


    public static void main(String[] args) {

    }
}
